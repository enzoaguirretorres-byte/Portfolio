# Enzo Aguirre Portfolio Site

This is a GitHub Pages-ready static portfolio site.

## How to use

1. Create a GitHub repository, for example `Portfolio`.
2. Upload everything in this folder to the repository root:
   - `index.html`
   - `styles.css`
   - `script.js`
   - `assets/`
3. In GitHub, go to **Settings → Pages**.
4. Under **Build and deployment**, set source to **Deploy from a branch**.
5. Choose the `main` branch and root folder.
6. Your site will publish at a URL like:
   `https://YOUR-USERNAME.github.io/Portfolio/`

## Things to replace

- In `index.html`, replace the LinkedIn placeholder in the Contact section with your actual LinkedIn URL.
- Add your own headshot or logo if you want a more personal hero section.
- Update project images later with real CAD screenshots, prototype photos, or FEA plots for a stronger portfolio.

## Suggested next edits

- Add a dedicated image for the brake assembly project.
- Add a stronger headline if you are targeting a specific industry, such as automotive, defense, or product design.
- Add direct links to project videos, GitHub repos, or PDF case studies if available.
